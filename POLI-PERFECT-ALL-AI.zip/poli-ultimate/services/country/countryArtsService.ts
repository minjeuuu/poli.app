
import { generateWithRetry } from "../common";
export const fetchArts = async (countryName: string) => { return {}; };
