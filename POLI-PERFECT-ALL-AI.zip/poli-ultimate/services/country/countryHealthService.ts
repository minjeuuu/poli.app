
import { generateWithRetry } from "../common";
export const fetchHealthcare = async (countryName: string) => { return {}; };
