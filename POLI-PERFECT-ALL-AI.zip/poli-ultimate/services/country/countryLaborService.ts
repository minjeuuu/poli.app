
import { generateWithRetry } from "../common";
export const fetchLaborForce = async (countryName: string) => { return {}; };
