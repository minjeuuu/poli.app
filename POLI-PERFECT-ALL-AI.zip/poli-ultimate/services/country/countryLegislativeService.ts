
import { generateWithRetry } from "../common";
export const fetchLegislativeBranch = async (countryName: string) => { return {}; };
