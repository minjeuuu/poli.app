
import { generateWithRetry } from "../common";
export const fetchRenewables = async (countryName: string) => { return {}; };
