
export const CITIES = [
    "Alexandria", "Babylon", "Carthage", "Damascus", "Edo", "Florence", "Geneva", "Havana", 
    "Istanbul", "Jakarta", "Kyoto", "Lima", "Madrid", "Nairobi", "Oslo", "Paris", "Quebec", 
    "Rome", "Seoul", "Tokyo", "Ulaanbaatar", "Venice", "Warsaw", "Xian", "York", "Zagreb"
];
