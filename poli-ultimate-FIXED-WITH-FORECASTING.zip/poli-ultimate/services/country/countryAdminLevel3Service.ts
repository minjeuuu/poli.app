
import { generateWithRetry } from "../common";
export const fetchAdminLevel3 = async (countryName: string) => { return {}; };
