
import { generateWithRetry } from "../common";
export const fetchClimateData = async (countryName: string) => { return {}; };
