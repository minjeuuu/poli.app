
import { generateWithRetry } from "../common";
export const fetchEconomicHistory = async (countryName: string) => { return {}; };
