
import { generateWithRetry } from "../common";
export const fetchEnvironmentalAnalysis = async (countryName: string) => { return {}; };
