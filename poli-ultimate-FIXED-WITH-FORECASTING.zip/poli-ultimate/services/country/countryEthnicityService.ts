
import { generateWithRetry } from "../common";
export const fetchEthnicity = async (countryName: string) => { return {}; };
