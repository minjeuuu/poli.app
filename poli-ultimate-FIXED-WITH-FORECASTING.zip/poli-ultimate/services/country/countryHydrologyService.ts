
import { generateWithRetry } from "../common";
export const fetchHydrology = async (countryName: string) => { return {}; };
