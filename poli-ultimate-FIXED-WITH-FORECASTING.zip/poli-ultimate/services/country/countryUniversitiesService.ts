
import { generateWithRetry } from "../common";
export const fetchUniversities = async (countryName: string) => { return {}; };
