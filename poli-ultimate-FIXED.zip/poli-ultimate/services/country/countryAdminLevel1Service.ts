
import { generateWithFallback } from "../common";
export const fetchAdminLevel1 = async (countryName: string) => { return {}; };
