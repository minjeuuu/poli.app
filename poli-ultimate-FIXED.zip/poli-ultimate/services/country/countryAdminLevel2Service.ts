
import { generateWithFallback } from "../common";
export const fetchAdminLevel2 = async (countryName: string) => { return {}; };
