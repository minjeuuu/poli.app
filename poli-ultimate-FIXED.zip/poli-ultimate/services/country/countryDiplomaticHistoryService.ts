
import { generateWithFallback } from "../common";
export const fetchDiplomaticHistory = async (countryName: string) => { return {}; };
