
import { generateWithFallback } from "../common";
export const fetchDocuments = async (countryName: string) => { return {}; };
