
import { generateWithFallback } from "../common";
export const fetchEconomyOverview = async (countryName: string) => { return {}; };
