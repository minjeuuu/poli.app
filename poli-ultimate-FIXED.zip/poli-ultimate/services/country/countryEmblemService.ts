
import { generateWithFallback } from "../common";
export const fetchCountryEmblem = async (countryName: string) => { return {}; };
