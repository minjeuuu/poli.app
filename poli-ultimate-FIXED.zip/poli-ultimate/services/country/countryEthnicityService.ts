
import { generateWithFallback } from "../common";
export const fetchEthnicity = async (countryName: string) => { return {}; };
