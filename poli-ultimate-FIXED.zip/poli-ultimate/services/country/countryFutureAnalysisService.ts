
import { generateWithFallback } from "../common";
export const fetchFutureAnalysis = async (countryName: string) => { return {}; };
