
import { generateWithFallback } from "../common";
export const fetchAncientHistory = async (countryName: string) => { return {}; };
