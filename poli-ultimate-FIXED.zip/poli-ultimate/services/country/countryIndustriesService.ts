
import { generateWithFallback } from "../common";
export const fetchIndustries = async (countryName: string) => { return {}; };
