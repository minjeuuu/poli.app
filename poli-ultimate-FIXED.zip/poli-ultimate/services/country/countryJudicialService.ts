
import { generateWithFallback } from "../common";
export const fetchJudicialBranch = async (countryName: string) => { return {}; };
