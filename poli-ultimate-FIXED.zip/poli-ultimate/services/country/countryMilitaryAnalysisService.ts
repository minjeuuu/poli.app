
import { generateWithFallback } from "../common";
export const fetchMilitaryAnalysis = async (countryName: string) => { return {}; };
