
import { generateWithFallback } from "../common";
export const fetchMilitaryOverview = async (countryName: string) => { return {}; };
