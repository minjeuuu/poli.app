
import { generateWithFallback } from "../common";
export const fetchPopulationStats = async (countryName: string) => { return {}; };
