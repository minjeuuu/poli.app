
import { generateWithFallback } from "../common";
export const fetchReligions = async (countryName: string) => { return {}; };
