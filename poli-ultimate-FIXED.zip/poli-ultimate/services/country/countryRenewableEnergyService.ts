
import { generateWithFallback } from "../common";
export const fetchRenewables = async (countryName: string) => { return {}; };
