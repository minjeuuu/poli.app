
import { generateWithFallback } from "../common";
export const fetchTechAnalysis = async (countryName: string) => { return {}; };
