
import { generateWithFallback } from "../common";
export const fetchTelecom = async (countryName: string) => { return {}; };
