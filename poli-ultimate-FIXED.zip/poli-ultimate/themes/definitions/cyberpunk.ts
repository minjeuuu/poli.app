
export const CYBERPUNK_THEME = {
    bg: "bg-slate-950",
    text: "text-cyan-400",
    accent: "text-pink-500",
    border: "border-cyan-900",
    surface: "bg-slate-900",
    input: "bg-black"
};
