
import { generateWithFallback } from "../common";
export const fetchClimateData = async (countryName: string) => { return {}; };
