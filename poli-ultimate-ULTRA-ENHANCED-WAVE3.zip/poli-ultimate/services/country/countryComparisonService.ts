
import { generateWithFallback } from "../common";
export const fetchComparisons = async (countryName: string) => { return {}; };
