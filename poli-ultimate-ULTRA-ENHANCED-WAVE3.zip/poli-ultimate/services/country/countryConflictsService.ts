
import { generateWithFallback } from "../common";
export const fetchConflicts = async (countryName: string) => { return {}; };
