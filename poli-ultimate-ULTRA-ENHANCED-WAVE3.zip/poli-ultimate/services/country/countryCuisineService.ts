
import { generateWithFallback } from "../common";
export const fetchCuisine = async (countryName: string) => { return {}; };
