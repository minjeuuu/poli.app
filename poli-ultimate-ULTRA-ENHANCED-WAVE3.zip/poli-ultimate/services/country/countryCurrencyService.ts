
import { generateWithFallback } from "../common";
export const fetchCurrencyData = async (countryName: string) => { return {}; };
