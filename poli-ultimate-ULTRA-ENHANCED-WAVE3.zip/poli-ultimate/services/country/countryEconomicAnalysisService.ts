
import { generateWithFallback } from "../common";
export const fetchEconomicAnalysis = async (countryName: string) => { return {}; };
