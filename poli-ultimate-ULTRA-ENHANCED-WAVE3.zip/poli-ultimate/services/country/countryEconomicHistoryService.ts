
import { generateWithFallback } from "../common";
export const fetchEconomicHistory = async (countryName: string) => { return {}; };
