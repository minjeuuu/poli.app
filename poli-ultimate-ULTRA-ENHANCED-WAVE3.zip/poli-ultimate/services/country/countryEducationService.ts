
import { generateWithFallback } from "../common";
export const fetchEducation = async (countryName: string) => { return {}; };
