
import { generateWithFallback } from "../common";
export const fetchEnergyOverview = async (countryName: string) => { return {}; };
