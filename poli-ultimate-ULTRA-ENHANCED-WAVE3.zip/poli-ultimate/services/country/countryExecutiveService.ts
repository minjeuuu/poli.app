
import { generateWithFallback } from "../common";
export const fetchExecutiveBranch = async (countryName: string) => { return {}; };
