
import { generateWithFallback } from "../common";
export const fetchModernHistory = async (countryName: string) => { return {}; };
