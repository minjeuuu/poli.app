
import { generateWithFallback } from "../common";
export const fetchHydrology = async (countryName: string) => { return {}; };
