
import { generateWithFallback } from "../common";
export const fetchRoads = async (countryName: string) => { return {}; };
