
import { generateWithFallback } from "../common";
export const fetchLaborForce = async (countryName: string) => { return {}; };
