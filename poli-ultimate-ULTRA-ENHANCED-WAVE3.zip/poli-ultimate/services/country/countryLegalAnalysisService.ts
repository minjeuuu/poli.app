
import { generateWithFallback } from "../common";
export const fetchLegalAnalysis = async (countryName: string) => { return {}; };
