
import { generateWithFallback } from "../common";
export const fetchLegislativeBranch = async (countryName: string) => { return {}; };
