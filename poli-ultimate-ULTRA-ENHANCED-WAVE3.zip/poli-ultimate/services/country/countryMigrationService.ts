
import { generateWithFallback } from "../common";
export const fetchMigration = async (countryName: string) => { return {}; };
