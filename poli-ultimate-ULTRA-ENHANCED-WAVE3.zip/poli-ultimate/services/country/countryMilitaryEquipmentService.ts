
import { generateWithFallback } from "../common";
export const fetchMilitaryEquipment = async (countryName: string) => { return {}; };
