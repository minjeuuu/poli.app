
import { generateWithFallback } from "../common";
export const fetchNaturalResources = async (countryName: string) => { return {}; };
