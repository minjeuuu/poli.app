
import { generateWithFallback } from "../common";
export const fetchPoliticalHistory = async (countryName: string) => { return {}; };
