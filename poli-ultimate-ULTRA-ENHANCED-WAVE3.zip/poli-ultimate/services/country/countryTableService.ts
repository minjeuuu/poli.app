
import { generateWithFallback } from "../common";
export const fetchTables = async (countryName: string) => { return {}; };
