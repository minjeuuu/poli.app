
import { generateWithFallback } from "../common";
export const fetchUrbanization = async (countryName: string) => { return {}; };
