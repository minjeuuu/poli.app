
export const POLITICAL_NOUNS = [
    "Republic", "Federation", "Confederation", "Union", "Empire", "Kingdom", "Principality", 
    "Duchy", "Sultanate", "Emirate", "Caliphate", "State", "Commonwealth", "Dominion", 
    "Protectorate", "Territory", "Province", "Region", "Zone", "Sector"
];
