
export const MODERN_BOOKS = [
    { title: "Leviathan", author: "Thomas Hobbes", year: "1651" },
    { title: "Two Treatises of Government", author: "John Locke", year: "1689" },
    { title: "The Social Contract", author: "Jean-Jacques Rousseau", year: "1762" },
    { title: "On Liberty", author: "John Stuart Mill", year: "1859" }
];
