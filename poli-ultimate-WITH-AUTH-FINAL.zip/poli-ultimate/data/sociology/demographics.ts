
export const AGE_COHORTS = [
    { label: "0-14", male: 15, female: 14 },
    { label: "15-24", male: 10, female: 10 },
    { label: "25-54", male: 25, female: 26 },
    { label: "55-64", male: 8, female: 9 },
    { label: "65+", male: 6, female: 7 },
];
