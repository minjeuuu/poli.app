
import { generateWithRetry } from "../common";
export const fetchEconomicAnalysis = async (countryName: string) => { return {}; };
