
import { generateWithRetry } from "../common";
export const fetchExecutiveBranch = async (countryName: string) => { return {}; };
