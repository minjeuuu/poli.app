
import { generateWithRetry } from "../common";
export const fetchFutureAnalysis = async (countryName: string) => { return {}; };
