
import { generateWithRetry } from "../common";
export const fetchMedievalHistory = async (countryName: string) => { return {}; };
