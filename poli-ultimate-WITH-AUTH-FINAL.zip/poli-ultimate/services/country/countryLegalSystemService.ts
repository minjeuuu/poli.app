
import { generateWithRetry } from "../common";
export const fetchLegalSystem = async (countryName: string) => { return {}; };
