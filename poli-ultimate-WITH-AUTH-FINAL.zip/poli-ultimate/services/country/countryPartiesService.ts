
import { generateWithRetry } from "../common";
export const fetchPoliticalParties = async (countryName: string) => { return {}; };
