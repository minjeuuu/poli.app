
import { generateWithRetry } from "../common";
export const fetchTechAnalysis = async (countryName: string) => { return {}; };
