
export const DARK_THEME = {
    bg: "bg-stone-950",
    text: "text-stone-100",
    accent: "text-indigo-400",
    border: "border-stone-800",
    surface: "bg-stone-900",
    input: "bg-stone-800"
};
