
export const POLITICAL_ADJECTIVES = [
    "Sovereign", "Autonomous", "Federal", "Unitary", "Democratic", "Authoritarian", 
    "Totalitarian", "Liberal", "Conservative", "Progressive", "Reactionary", "Radical", 
    "Moderate", "Extremist", "Secular", "Theocratic", "Militarist", "Pacifist"
];
