
export const ANCIENT_BOOKS = [
    { title: "The Republic", author: "Plato", year: "375 BCE" },
    { title: "Politics", author: "Aristotle", year: "335 BCE" },
    { title: "The Art of War", author: "Sun Tzu", year: "5th C. BCE" },
    { title: "Meditations", author: "Marcus Aurelius", year: "180 CE" }
];
