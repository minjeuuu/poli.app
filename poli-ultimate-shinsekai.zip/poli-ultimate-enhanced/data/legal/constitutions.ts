
export const CONSTITUTIONS = [
    { country: "USA", year: 1787, type: "Codified" },
    { country: "UK", year: 1215, type: "Uncodified" },
    { country: "India", year: 1950, type: "Codified" },
    { country: "France", year: 1958, type: "Codified" },
    { country: "Japan", year: 1947, type: "Codified" }
];
