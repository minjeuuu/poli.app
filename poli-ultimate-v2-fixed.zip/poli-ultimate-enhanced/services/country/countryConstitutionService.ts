
import { generateWithRetry } from "../common";
export const fetchConstitution = async (countryName: string) => { return {}; };
