
import { generateWithRetry } from "../common";
export const fetchDiplomaticHistory = async (countryName: string) => { return {}; };
