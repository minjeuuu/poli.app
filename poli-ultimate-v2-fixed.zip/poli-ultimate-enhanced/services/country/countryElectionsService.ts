
import { generateWithRetry } from "../common";
export const fetchElections = async (countryName: string) => { return {}; };
