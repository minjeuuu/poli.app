
import { generateWithRetry } from "../common";
export const fetchForeignPolicy = async (countryName: string) => { return {}; };
