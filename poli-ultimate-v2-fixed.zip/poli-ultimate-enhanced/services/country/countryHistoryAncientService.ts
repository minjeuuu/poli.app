
import { generateWithRetry } from "../common";
export const fetchAncientHistory = async (countryName: string) => { return {}; };
