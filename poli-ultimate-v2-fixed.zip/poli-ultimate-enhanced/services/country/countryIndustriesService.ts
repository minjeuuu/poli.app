
import { generateWithRetry } from "../common";
export const fetchIndustries = async (countryName: string) => { return {}; };
