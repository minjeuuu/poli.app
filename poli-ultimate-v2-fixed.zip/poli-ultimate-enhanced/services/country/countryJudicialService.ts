
import { generateWithRetry } from "../common";
export const fetchJudicialBranch = async (countryName: string) => { return {}; };
