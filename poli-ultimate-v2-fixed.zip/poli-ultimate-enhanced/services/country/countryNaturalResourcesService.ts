
import { generateWithRetry } from "../common";
export const fetchNaturalResources = async (countryName: string) => { return {}; };
