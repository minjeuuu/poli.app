
import { generateWithRetry } from "../common";
export const fetchPopulationStats = async (countryName: string) => { return {}; };
