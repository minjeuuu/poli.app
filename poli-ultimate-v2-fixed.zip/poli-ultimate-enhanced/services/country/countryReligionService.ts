
import { generateWithRetry } from "../common";
export const fetchReligions = async (countryName: string) => { return {}; };
