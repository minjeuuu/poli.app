
import { generateWithRetry } from "../common";
export const fetchTables = async (countryName: string) => { return {}; };
